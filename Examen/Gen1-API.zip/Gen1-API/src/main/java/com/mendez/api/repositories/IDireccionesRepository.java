package com.mendez.api.repositories;


import com.mendez.api.models.Direccion;

import java.sql.SQLException;

public interface IDireccionesRepository extends IRepository<Direccion>{
    Long guardarReturnId(Direccion direccion) throws SQLException;
}
