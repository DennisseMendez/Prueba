package com.mendez.api.controllers;

import com.google.gson.Gson;
import com.mendez.api.models.Direccion;
import com.mendez.api.models.Ruta;
import com.mendez.api.services.DireccionesService;
import com.mendez.api.services.IDireccionesService;
import com.mendez.api.services.IRutasService;
import com.mendez.api.services.RutasService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;


@WebServlet("/api/rutas")
public class apiRutas extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Connection conn = (Connection) req.getAttribute("conn");
        IRutasService service = new RutasService(conn);
        try {
            Thread.sleep(5000);
        }catch (InterruptedException e){
            throw new RuntimeException(e);
        }
        String chofer = req.getParameter("chofer");
        String origen = req.getParameter("origen");
        String FSalida = req.getParameter("FSalida");
        String distancia = req.getParameter("distancia");
        String camion = req.getParameter("camion");
        String destino = req.getParameter("destino");
        String FELlegada = req.getParameter("FELlegada");


        Ruta ruta = new Ruta();
        ruta.setChoferId(Long.valueOf(chofer));
        ruta.setDireccionOrigenId(Long.valueOf(origen));
        ruta.setFechaSalida(LocalDate.parse(FSalida));
        ruta.setDistancia(Float.valueOf(distancia));
        ruta.setCamionId(Long.valueOf(camion));
        ruta.setDireccionDestidoId(Long.valueOf(destino));
        ruta.setFechaLlegadaEstimada(LocalDate.parse(FELlegada));

        resp.setContentType("aplication/json");
        Map<String, String> respuesta = new HashMap<>();
        if(chofer == null || origen == null || FSalida == null || distancia == null
                || camion == null || destino ==  null || FELlegada == null){
            try (PrintWriter out = resp.getWriter()) {
                resp.setStatus(400);
                respuesta.put("message", "Debes ingresar todos los valores");
                respuesta.put("estatus", "error");
                String json = new Gson().toJson(respuesta);
                out.print(json);
            }
        }
        else
        {
            Long id = service.guardarReturnId(ruta);
            try (PrintWriter out = resp.getWriter()){
                resp.setStatus(201);
                respuesta.put("message", id.toString());
                respuesta.put("estatus", "success");
                String json = new Gson().toJson(respuesta);
                out.print(json);
            }
        }
    }
}
