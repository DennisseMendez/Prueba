package com.mendez.api.repositories;


import com.mendez.api.models.Ruta;

import java.sql.SQLException;

public interface IRutasRepository extends IRepository<Ruta>{
    Long guardarReturnId(Ruta ruta) throws SQLException;
}
