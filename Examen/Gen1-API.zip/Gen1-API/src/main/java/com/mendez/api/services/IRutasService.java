package com.mendez.api.services;

import com.mendez.api.models.Camion;
import com.mendez.api.models.Chofer;
import com.mendez.api.models.Ruta;


import java.util.List;

public interface IRutasService extends IService<Ruta>{

    List<Camion> listarCamiones();
    List<Chofer> listarChoferes();
    Long guardarReturnId(Ruta ruta);
}
