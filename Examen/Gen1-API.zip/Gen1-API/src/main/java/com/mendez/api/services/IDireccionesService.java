package com.mendez.api.services;


import com.mendez.api.models.Direccion;

public interface IDireccionesService extends IService<Direccion>{
    Long guardarReturId(Direccion direccion);
}
