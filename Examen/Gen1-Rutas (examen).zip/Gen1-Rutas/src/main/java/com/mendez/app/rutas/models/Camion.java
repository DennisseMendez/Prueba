package com.mendez.app.rutas.models;

import java.time.LocalDate;

public class Camion {


    //atributos


    private Long id;
    private String matricula;
    private String tpCamion;
    private Long modelo;
    private String marca;
    private Long capacidad;
    private Float kilometraje;
    private Boolean disponibilidad;



    //Setters and Getters


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public String getTpCamion() {
        return tpCamion;
    }

    public void setTpCamion(String tpCamion) {
        this.tpCamion = tpCamion;
    }

    public Long getModelo() {
        return modelo;
    }

    public void setModelo(Long modelo) {
        this.modelo = modelo;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public Long getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(Long capacidad) {
        this.capacidad = capacidad;
    }

    public Float getKilometraje() {
        return kilometraje;
    }

    public void setKilometraje(Float kilometraje) {
        this.kilometraje = kilometraje;
    }

    public Boolean getDisponibilidad() {
        return disponibilidad;
    }

    public void setDisponibilidad(Boolean disponibilidad) {
        this.disponibilidad = disponibilidad;
    }
}
