package com.mendez.app.rutas.controllers;

import com.mendez.app.rutas.models.Camion;
import com.mendez.app.rutas.models.Chofer;
import com.mendez.app.rutas.services.CamionesService;
import com.mendez.app.rutas.services.ChoferesService;
import com.mendez.app.rutas.services.IService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Connection;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@WebServlet("/camiones/editar")
public class EdicionCamionServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Connection conn = (Connection) req.getAttribute("conn");
        IService<Camion> service = new CamionesService(conn);
        Long id;
        try {
            id = Long.parseLong(req.getParameter("id"));
        } catch (NumberFormatException e) {
            id = 0L;
        }
        Camion camion = new Camion();
        if (id > 0) {
            Optional<Camion> o = service.getById(id);
            if (o.isPresent()) {
                camion = o.get();
                req.setAttribute("camion", camion);
                getServletContext().getRequestDispatcher("/edicionCamion.jsp")
                        .forward(req, resp);
            } else {
                resp.sendError(HttpServletResponse.SC_NOT_FOUND,
                        "No existe el camion en la base de datos");
            }
        } else {

            resp.sendError(HttpServletResponse.SC_NOT_FOUND,
                    "Error el is es null, se debe enviar como parametro en la url");
        }

     }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Connection conn = (Connection) req.getAttribute("conn");
        IService<Camion> service = new CamionesService(conn);



        String matricula = req.getParameter("matricula");
        String tpCamion = req.getParameter("tpCamion");
        String modelo = req.getParameter("modelo");
        String marca = req.getParameter("marca");
        String capacidad = req.getParameter("capacidad");
        String kilometraje = req.getParameter("kilometraje");


        String checkbox[];
        checkbox = req.getParameterValues("disponibilidad");
        Boolean habilitar;
        if (checkbox != null){
            habilitar = true;
        }
        else{
            habilitar = false;
        }

        Map<String, String> errores = new HashMap<>();
        if (matricula == null || matricula.isBlank()){
            errores.put("matricula", "la matricula es requerida");
        }
        if (tpCamion == null || tpCamion.isBlank()) {
            errores.put("tpCamion", "el tipo de Camion es requerido");
        }
        if (modelo == null || modelo.isBlank()) {
            errores.put("modelo", "el modelo es requerido");
        }
        if (marca == null || marca.isBlank()) {
            errores.put("marca", "la marca es requerida");
        }
        if (capacidad == null || capacidad.isBlank()) {
            errores.put("capacidad", "la capacidad es requerida");
        }
        if (kilometraje == null || kilometraje.isBlank()) {
            errores.put("kilometraje", "el kilometraje es  requerido");
        }

        Long id;
        id = Long.parseLong(req.getParameter("id")); //258
        Camion camion = new Camion();
        camion.setId(id);
        camion.setMatricula(matricula);
        camion.setTpCamion(tpCamion);
        camion.setModelo(Long.parseLong(modelo));
        camion.setMarca(marca);
        camion.setCapacidad(Long.parseLong(capacidad));
        camion.setKilometraje(Float.parseFloat(kilometraje));
        camion.setDisponibilidad(habilitar);
        if(errores.isEmpty())
        {

            service.guardar(camion);
            resp.sendRedirect(req.getContextPath()+ "/camiones/listar");

        }
        else {
            req.setAttribute("errores", errores);
            getServletContext().getRequestDispatcher("/edicionCamion.jsp")
                    .forward(req, resp);
        }

    }

}
