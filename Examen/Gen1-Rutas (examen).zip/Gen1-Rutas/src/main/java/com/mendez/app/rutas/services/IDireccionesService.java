package com.mendez.app.rutas.services;

import com.mendez.app.rutas.models.Direccion;

public interface IDireccionesService extends IService<Direccion>{
    Long guardarReturId(Direccion direccion);
}
