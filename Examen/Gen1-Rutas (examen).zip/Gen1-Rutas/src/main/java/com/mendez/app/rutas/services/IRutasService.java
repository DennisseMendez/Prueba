package com.mendez.app.rutas.services;

import com.mendez.app.rutas.models.Camion;
import com.mendez.app.rutas.models.Chofer;
import com.mendez.app.rutas.models.Ruta;

import java.util.List;

public interface IRutasService extends IService<Ruta>{

    List<Camion> listarCamiones();
    List<Chofer> listarChoferes();
    Long guardarReturnId(Ruta ruta);
}
