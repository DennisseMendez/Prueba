package com.mendez.app.rutas.models.enums;

public enum Tipos {
    TRAILER,
    TORTON,
    DOBLE_REMOLQUE,
    VOLTEO,
    SEMI_REMOLQUE
}
