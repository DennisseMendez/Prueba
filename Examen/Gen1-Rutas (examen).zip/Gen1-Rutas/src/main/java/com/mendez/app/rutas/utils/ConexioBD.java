package com.mendez.app.rutas.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexioBD {

    //ATRIBUTOS

    private static String url  = "jdbc:oracle:thin:@//127.0.0.1:1521/xe";
    private static  String username = "SYSTEM";
    private  static String password = "1234";



    //Metodo que establece la conexion al servidor de BD ORACLE

    public static Connection getInstance(){
        try {
            return DriverManager.getConnection(url, username, password);
        }catch (SQLException e){
            throw  new RuntimeException(e);
        }
    }
}
