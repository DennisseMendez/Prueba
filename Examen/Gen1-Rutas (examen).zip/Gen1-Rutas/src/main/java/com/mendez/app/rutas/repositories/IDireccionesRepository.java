package com.mendez.app.rutas.repositories;

import com.mendez.app.rutas.models.Direccion;

import java.sql.SQLException;

public interface IDireccionesRepository extends IRepository<Direccion>{
    Long guardarReturnId(Direccion direccion) throws SQLException;
}
