package com.mendez.app.rutas.services;

import com.mendez.app.rutas.models.Cargamento;
import com.mendez.app.rutas.repositories.CargamentoRepository;
import com.mendez.app.rutas.repositories.IRepository;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class CargamentosService implements IService<Cargamento>{



    //atributos

    private IRepository<Cargamento> cargamentoRepo;


    //constructor

    public CargamentosService(Connection conn) {
        cargamentoRepo = new CargamentoRepository(conn);
    }


    //metodos

    @Override
    public List<Cargamento> listar() {
        return null;
    }

    @Override
    public Optional<Cargamento> getById(Long id) {
        return Optional.empty();
    }

    @Override
    public void guardar(Cargamento cargamento) {
        try {
            cargamentoRepo.guardar(cargamento);

        }catch (SQLException e) {
            throw new RuntimeException(e.getMessage(), e.getCause());
        }
    }

    @Override
    public void eliminar(Long id) {

    }
}
