package com.mendez.app.rutas.controllers;

import com.mendez.app.rutas.models.Camion;
import com.mendez.app.rutas.models.Chofer;
import com.mendez.app.rutas.models.enums.Marcas;
import com.mendez.app.rutas.models.enums.Tipos;
import com.mendez.app.rutas.services.CamionesService;
import com.mendez.app.rutas.services.ChoferesService;
import com.mendez.app.rutas.services.IService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Connection;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

@WebServlet("/camiones/alta")
public class AltaCamionServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {


        Calendar l = new GregorianCalendar();
        Integer[] anios = new Integer[22];
        String[] aniosS = new String[22];
        int a = 0;
        for (int i = -20; i< 2; i++)
        {
            anios[a]=(l.get(Calendar.YEAR))+i;
            a++;
        }
        a=0;
        for(Integer b : anios)
        {
            aniosS[a]= String.valueOf(b);
            a++;
        }

        Marcas[] marcas = Marcas.values();
        Tipos[] tipos = Tipos.values();
        req.setAttribute("tipos", tipos);
        req.setAttribute("marcas", marcas);
        req.setAttribute("anios", aniosS);

        getServletContext().getRequestDispatcher("/altaCamion.jsp").forward(req, resp);

    }





    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        Connection conn = (Connection) req.getAttribute("conn");
        IService<Camion> service = new CamionesService(conn);



        String matricula = req.getParameter("matricula"); //"QQQQQ"
        String tpCamion = req.getParameter("tpCamion");
        String modeloStr = req.getParameter("modelo");
        String marca = req.getParameter("marca");
        String capacidadStr = req.getParameter("capacidad");
        String kilometrajeStr = req.getParameter("kilometraje");

        //conversion

        // Convertir los valores de String a sus tipos correspondientes

        Integer modelo;
        Integer capacidad;
        Float kilometraje;

        try {
            modelo = Integer.parseInt(modeloStr);
        } catch (NumberFormatException e) {
            modelo = null;
        }

        try {
            capacidad = Integer.parseInt(capacidadStr);
        } catch (NumberFormatException e) {
            capacidad = null;
        }

        try {
            kilometraje = Float.parseFloat(kilometrajeStr);
        } catch (NumberFormatException e) {
            kilometraje = null;
        }

        try {
            modelo = Integer.parseInt(modeloStr);

        }catch (NumberFormatException e){
            modelo = null;
        }



        String checkbox[];
        checkbox = req.getParameterValues("disponibilidad");
        Boolean habilitar;
        if (checkbox != null){
            habilitar = true;
        }
        else{
            habilitar = false;
        }

        Map<String, String> errores = new HashMap<>();
        if (matricula == null || matricula.isBlank()){
            errores.put("matricula", "la matricula es requerido");
        }
        if (tpCamion == null || tpCamion.isBlank()) {
            errores.put("tpCamion", "el tpCamion es requerido");
        }
       /*if (modelo == null || modelo.isBlank()) {
            errores.put("modelo", "el modelo es requerido");
        }*/
        if (marca == null || marca.isBlank()) {
            errores.put("marca", "la marca es requerida");
        }
        /*if (capacidad == null || capacidad.isBlank()) {
            errores.put("capacidad", "la capacidad es requerida");
        }
        if (kilometraje == null || kilometraje.isBlank()) {
            errores.put("capacidad", "la capacidad es requerida");
        }*/
        if(errores.isEmpty())
        {
            Camion camion = new Camion();
            camion.setId(0L);

            camion.setMatricula(matricula);
            camion.setTpCamion(tpCamion);
            camion.setModelo(Long.parseLong(modeloStr));
            camion.setMarca(marca);
            camion.setCapacidad(Long.parseLong(capacidadStr));
            camion.setKilometraje(Float.parseFloat(kilometrajeStr));
            camion.setDisponibilidad(habilitar);
            service.guardar(camion);
            resp.sendRedirect(req.getContextPath()+ "/camiones/listar");

        }
        else {
            req.setAttribute("errores", errores);
            getServletContext().getRequestDispatcher("/altaCamion.jsp")
                    .forward(req, resp);
        }
    }
}
